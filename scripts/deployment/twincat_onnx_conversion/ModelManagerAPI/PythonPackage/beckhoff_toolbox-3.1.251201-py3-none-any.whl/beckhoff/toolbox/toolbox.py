###################################################################################################
##
##
##   toolbox.py
##   ==========
##
###################################################################################################
##
##   Company:     Beckhoff Automation GmbH & Co.KG
##   Copyright:   see legal info file
##
###################################################################################################


__all__ = ['hwinfo', 'info', 'store', 'onnximport', 'convert', 'modify','predict']
__name__ = "toolbox"

###################################################################################################


import ctypes as _ct
import xml.etree.ElementTree as _ET
import os.path as _path
import platform
import sys
sys.dont_write_bytecode = True


class Options:
    Silent_Mode = False  # Does not show file info after operation


class _MLlibUM_DLLwrapper:
    # Static variables
    _MLlib_UM_XML_CallbackFnFUNC = None
    _MLlib_UM_ExecuteCommand = None
    _MLlib_UM_MsgLvl = 'warning'

            

    @staticmethod
    def _XML_CallbackFn_loading(xml_message, xml_message_length, passalong_p):
        root = _ET.fromstring(xml_message)
        if root.tag != "MLlibXMLmsg":
            raise ValueError("Unexpected callback message structure")

        if root.attrib['type'] == 'version':
            print(root.attrib['name'] + " UM DLL version " + root.attrib['version'] + ", build for " + root.attrib[
                'platform'] + '/' + root.attrib['build'] + " using " + root.attrib['compiler'])
        else:
            raise ValueError("Unexpected callback message structure")

    @staticmethod
    def _LoadDLLfunctions():
        if _MLlibUM_DLLwrapper._MLlib_UM_ExecuteCommand is None:
            # Load the DLL
            if 'Windows' in platform.system():
                _MLlibUM_DLLwrapper._MLlib_UM_XML_CallbackFnFUNC = _ct.WINFUNCTYPE(None, _ct.c_char_p, _ct.c_ulong, _ct.c_void_p)
                beckhoff_mllib_um_dll_abspath = _path.dirname(_path.abspath(__file__)) + _path.sep + "mllib_um.dll"
                beckhoff_mllib_um_dll = _ct.WinDLL(beckhoff_mllib_um_dll_abspath)
                
                # Retrieve the 'MLlib_API_GetVersion' function
                MLlib_UM_GetVersion_ApiProto = _ct.WINFUNCTYPE(
                    _ct.c_long,  # Return type.
                    _ct.c_void_p)  # 64-bit MLlib version contained in DLL
                MLlib_UM_GetVersion = MLlib_UM_GetVersion_ApiProto(("MLlib_API_GetVersion", beckhoff_mllib_um_dll))
                # Retrieve and check the DLL API version
                p1 = _ct.c_ulonglong(0)
                api_ver = MLlib_UM_GetVersion(_ct.byref(p1))

                if api_ver != 1:
                    raise ValueError("The MLlib UM DLL has an unsupported API version.")

                # Retrieve the 'MLlib_ExecuteCommand' function
                MLlib_UM_ExecuteCommand_ApiProto = _ct.WINFUNCTYPE(
                    _ct.c_long,  # Return type.
                    _ct.c_char_p,  # XML command string
                    _ct.c_ulong,  # XML command string length
                    _MLlibUM_DLLwrapper._MLlib_UM_XML_CallbackFnFUNC,  # XML callback function
                    _ct.c_void_p)  # Callback function pass-along
                _MLlibUM_DLLwrapper._MLlib_UM_ExecuteCommand = MLlib_UM_ExecuteCommand_ApiProto(
                    ("MLlib_ExecuteCommand", beckhoff_mllib_um_dll))
                
            else:
                _MLlibUM_DLLwrapper._MLlib_UM_XML_CallbackFnFUNC = _ct.CFUNCTYPE(None, _ct.c_char_p, _ct.c_ulong, _ct.c_void_p)
                
                beckhoff_mllib_um_dll_abspath = _path.dirname(_path.abspath(__file__)) + _path.sep + "libmllib_um.so"
                beckhoff_mllib_um_dll = _ct.CDLL(beckhoff_mllib_um_dll_abspath)
                
                                # Retrieve the 'MLlib_API_GetVersion' function
                MLlib_UM_GetVersion_ApiProto = _ct.CFUNCTYPE(
                    _ct.c_long,  # Return type.
                    _ct.c_void_p)  # 64-bit MLlib version contained in DLL
                MLlib_UM_GetVersion = MLlib_UM_GetVersion_ApiProto(("MLlib_API_GetVersion", beckhoff_mllib_um_dll))
                # Retrieve and check the DLL API version
                p1 = _ct.c_ulonglong(0)
                api_ver = MLlib_UM_GetVersion(_ct.byref(p1))

                if api_ver != 1:
                    raise ValueError("The MLlib UM DLL has an unsupported API version.")

                # Retrieve the 'MLlib_ExecuteCommand' function
                MLlib_UM_ExecuteCommand_ApiProto = _ct.CFUNCTYPE(
                    _ct.c_long,  # Return type.
                    _ct.c_char_p,  # XML command string
                    _ct.c_ulong,  # XML command string length
                    _MLlibUM_DLLwrapper._MLlib_UM_XML_CallbackFnFUNC,  # XML callback function
                    _ct.c_void_p)  # Callback function pass-along
                _MLlibUM_DLLwrapper._MLlib_UM_ExecuteCommand = MLlib_UM_ExecuteCommand_ApiProto(
                    ("MLlib_ExecuteCommand", beckhoff_mllib_um_dll))



            MLlib_UM_XML_CallbackFn_func = _MLlibUM_DLLwrapper._MLlib_UM_XML_CallbackFnFUNC(
                _MLlibUM_DLLwrapper._XML_CallbackFn_loading)

            ret_val = _MLlibUM_DLLwrapper._MLlib_UM_ExecuteCommand(_ct.c_char_p(), 0, MLlib_UM_XML_CallbackFn_func,
                                                                   _ct.c_void_p())

    def __init__(self):
        self._LoadDLLfunctions()

    @staticmethod
    def _PrepareInputOutputXML(inputfiles, outputfiles):
        def _AddFileList(flist, type):
            xmlstr = "<" + type + ">"
            if flist is None:
                return ""
            if isinstance(flist, str):
                flist = [flist]
            for f in flist:
                eng = ''
                ref = ''
                iref = ''
                if isinstance(f, dict):
                    eng = f.get('eng', '')
                    ref = f.get('ref', '')
                    iref = f.get('iref', '')
                    f = f['filename']

                fext = _path.splitext(f)[1]
                if len(fext) > 0:
                    if fext[0] == '.':
                        fext = fext[1:]
                fext = fext.lower()
                if fext in ['onnx', 'xml', 'bml', 'json']:
                    fstr = '<File type="' + fext + '" name="' + f + '"'
                    if len(eng) > 0:
                        fstr += ' engine="' + eng + '"'
                    if len(ref) > 0:
                        fstr += ' ref="' + ref + '"'
                    if len(iref) > 0:
                        fstr += ' iref="' + iref + '"'
                    fstr += ' />'
                else:
                    raise ValueError("Unrecognized file name extension found.")
                xmlstr += fstr
            xmlstr += "</" + type + ">"
            return xmlstr

        return _AddFileList(inputfiles, "Inputs") + _AddFileList(outputfiles, "Outputs")

    @staticmethod
    def _FormXMLcmd(cmd: str, inputs, outputs, extraxml: str = '', addendum_xml: str = ''):
        xml = '<?xml version="1.0"?><MLlibXMLCommand command="' + cmd + '" message_level="' + _MLlibUM_DLLwrapper._MLlib_UM_MsgLvl + '" ' + addendum_xml + '>' \
              + _MLlibUM_DLLwrapper._PrepareInputOutputXML(inputs, outputs) + extraxml + '</MLlibXMLCommand>'
        return xml

    @staticmethod
    def _GatherModelInfo(model_xml_info: _ET.Element):
        mi = model_xml_info.attrib.copy()
        mi["input_dim"] = int(mi["input_dim"])
        mi["output_dim"] = int(mi["output_dim"])

        auxspecs = model_xml_info.find("AuxiliarySpecifications")
        pti = auxspecs.find("PTI")
        mi["has_pti"] = False
        mi["producer"] = ""
        mi["producer_ver"] = ""
        mi["req_target_ver"] = ""
        if pti is not None:
            mi["has_pti"] = True
            if "str_producer" in pti.attrib: mi["producer"] = pti.attrib["str_producer"]
            if "str_producerVersion" in pti.attrib: mi["producer_ver"] = pti.attrib["str_producerVersion"]
            if "str_requiredVersion" in pti.attrib: mi["req_target_ver"] = pti.attrib["str_requiredVersion"]

        iospec = model_xml_info.find("IOSpec")
        mi["default_engine_type"] = ""
        mi["preferred_input_types"] = ""
        mi["supported_input_types"] = ""
        mi["preferred_output_types"] = ""
        mi["supported_output_types"] = ""
        if iospec is not None:
            mi["default_engine_type"] = iospec.attrib["engine_type"]
            mi["preferred_input_types"] = iospec.attrib["preferred_input_types"].split(" ")
            mi["supported_input_types"] = iospec.attrib["supported_input_types"].split(" ")
            mi["preferred_output_types"] = iospec.attrib["preferred_output_types"].split(" ")
            mi["supported_output_types"] = iospec.attrib["supported_output_types"].split(" ")

        mi["engines"] = []
        mi["io_distributors"] = {}
        component = model_xml_info.find("Components")
        if component is not None:
            for eng in component.iter("Engine"):
                mi["engines"].append(eng.attrib["identifier"])
            for distr in component.iter("IODistributor"):
                dengl = []
                for deng in distr.iter("DistributorEngine"):
                    dengl.append(deng.attrib.copy())
                distrib = distr.attrib.copy()
                distrib.update({"engines": dengl})
                mi["io_distributors"].update({distr.attrib["identifier"]: distrib})

        def _XMLtoDict_rec(parent_elem, parent_dict):
            for a, v in parent_elem.attrib.items():
                tmp = a[0:5]
                elem_mode = True
                if a[0:3] == "arr":
                    elem_mode = False
                    a = a[3:]
                if a[0:5] == "bool_":
                    parent_dict[a[5:]] = v.lower() in ["true", "1"] if elem_mode else [(e.lower() in ["true", "1"]) for e in v.split(',')]
                elif a[0:4] == "str_":
                    if elem_mode:
                        parent_dict[a[5:]] = v
                    else:
                        raise ValueError("Invalid array string attribute.")
                elif a[0:5] == "fp32_":
                    parent_dict[a[5:]] = float(v) if elem_mode else [float(e) for e in v.split(',')]
                elif a[0:5] == "fp64_":
                    parent_dict[a[5:]] = float(v) if elem_mode else [float(e) for e in v.split(',')]
                elif a[0:4] == "int_":
                    parent_dict[a[4:]] = int(v) if elem_mode else [int(e) for e in v.split(',')]
                elif a[0:5] == "int8_":
                    parent_dict[a[5:]] = int(v) if elem_mode else [int(e) for e in v.split(',')]
                elif a[0:6] == "int16_":
                    parent_dict[a[6:]] = int(v) if elem_mode else [int(e) for e in v.split(',')]
                elif a[0:6] == "int32_":
                    parent_dict[a[6:]] = int(v) if elem_mode else [int(e) for e in v.split(',')]
                elif a[0:6] == "int64_":
                    parent_dict[a[6:]] = int(v) if elem_mode else [int(e) for e in v.split(',')]
                else:
                    raise ValueError("Unrecognized data type found in custom attributes")
            # for c in parent_elem.getchildren():
            for c in list(parent_elem):
                new_dict = {}
                _XMLtoDict_rec(c, new_dict)
                parent_dict[c.tag] = new_dict

        ca_dict = {}
        custatt = model_xml_info.find("CustomAttributes")
        if custatt is not None:
            _XMLtoDict_rec(custatt, ca_dict)
        mi["CustomAttributes"] = ca_dict.copy()

        return mi

    @staticmethod
    def _PrintModelInfo(mi):
        indent = "    "
        listjoiner = " "
        info = indent + "model type:           " + mi["model_type"] + "\n" \
               + indent + "model info:           " + mi["model_info"] + "\n"
        info += indent + "input dimension:      " + str(mi["input_dim"]) + "\n" \
                + indent + "output dimension:     " + str(mi["output_dim"]) + "\n"
        info += indent + "auto-selected engine: " + mi["auto_selected_engine"] + "\n"
        info += indent + " - input types:       " + listjoiner.join(mi["supported_input_types"]) + "  (" \
                + listjoiner.join(mi["preferred_input_types"]) + " preferred)\n"
        info += indent + " - output types:      " + listjoiner.join(mi["supported_output_types"]) + "  (" \
                + listjoiner.join(mi["preferred_output_types"]) + " preferred)\n"
        info += indent + "total components:     " + str(len(mi["engines"])) + " engine(s), " + str(
            len(mi["io_distributors"])) + " I/O distributor(s)"

        print(info)
        return mi

    @staticmethod
    def _ShowIOModelInfo(response: _ET.Element):
        input_mi = []
        for inp in response.iterfind("Input"):
            minf = inp.find("ModelInfo")
            input_mi.append(_MLlibUM_DLLwrapper._GatherModelInfo(minf))
            if not Options.Silent_Mode:
                if inp.attrib["type"] == "file":
                    print("Input model file '" + inp.attrib["file"] + "':")
                    _MLlibUM_DLLwrapper._PrintModelInfo(input_mi[-1])
        output_mi = []
        for outp in response.iterfind("Output"):
            minf = outp.find("ModelInfo")
            output_mi.append(_MLlibUM_DLLwrapper._GatherModelInfo(minf))
            if not Options.Silent_Mode:
                if outp.attrib["type"] == "file":
                    print("Output model file '" + outp.attrib["file"] + "':")
                    _MLlibUM_DLLwrapper._PrintModelInfo(output_mi[-1])
        print()
        return (input_mi, output_mi)

    @staticmethod
    def _ExecXMLcmd(xml_cmd: bytes):
        msg_list = []

        def _XML_CallbackFn_test(xml_message: _ct.c_char_p, xml_message_length: _ct.c_ulong,
                                 passalong_p: _ct.c_void_p) -> None:
            root = _ET.fromstring(xml_message)
            if root.tag != "MLlibXMLmsg":
                raise ValueError("Unexpected callback message structure")

            msg_list.append(root)
            if root.attrib['type'] == 'error':
                err_str = "ERROR: " + root.attrib['code'];
                if len(root.attrib['description']) > 0:
                    err_str += " - " + root.attrib['description']
                err_str += "; thrown in function '" + root.attrib['srcfile'] + "' located in '" + root.attrib[
                    'srcfile'] + "' line " + str(root.attrib['srcline'])
                print(err_str)
            elif root.attrib['type'] == 'warning':
                warn_str = "WARNING: " + root.attrib['code'];
                if len(root.attrib['description']) > 0:
                    warn_str += " - " + root.attrib['description']
                print(warn_str)
            # elif root.attrib['type'] == 'response':
            #    print(xml_message)

        if _MLlibUM_DLLwrapper._MLlib_UM_ExecuteCommand is None:
            raise RuntimeError("Beckhoff MLlib UM DLL not initialized")

        _callback_fn = _MLlibUM_DLLwrapper._MLlib_UM_XML_CallbackFnFUNC(_XML_CallbackFn_test);
        msg_list.clear()
        _MLlibUM_DLLwrapper._MLlib_UM_ExecuteCommand(_ct.c_char_p(xml_cmd), len(xml_cmd), _callback_fn, _ct.c_void_p())
        if len(msg_list) > 0:
            response = msg_list[-1]
            if response.attrib['type'] == 'response':
                return (msg_list, response)
        return (msg_list, None)


###################################################################################################
###################################################################################################


# Initialization via (dummy) instantiation, loads the DLL
_MLlibUM_DLLwrapper()


###################################################################################################
###################################################################################################


def onnximport(onnx_file: str, target_file: str):
    # Imports an ONNX file and attempts to interpret its contents as a multi-layer perceptron type
    # neural network. This MLP is stored in the target file Beckhoff machine learning XML or BML model file.
    if len(onnx_file) < 1:
        raise ValueError("No ONNX input file specified.")
    if len(target_file) < 1:
        raise ValueError("No output file for ONNX import specified.")
    if ".xml" not in target_file and ".bml" not in target_file:
        raise ValueError("Output file has to be .xml or .bml file")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('onnximport', onnx_file, target_file), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'onnximport' command, see console output")

    onnximport_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return onnximport_mi[0][0].copy()


def onnxprep(onnx_path : str):
    if len(onnx_path) < 1:
        raise ValueError("No input file specified.")
    if not ((".onnx" in onnx_path)):
        raise ValueError("Input file has to be .onnx file")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('onnxprep', onnx_path, None), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'onnxprep' command, see console output")

    mesg = "Onnxprep successful."
    return mesg

def xmlprep(xml_path : str, output_onnx_path:str=None):
    if len(xml_path) < 1:
        raise ValueError("No input file specified.")
    if not ((".xml" in xml_path) or (".bml" in xml_path)):
        raise ValueError("Input file has to be .xml or .bml file")
    if output_onnx_path!=None:
        if not ".onnx" in output_onnx_path:
            raise ValueError("Output file has to be .onnx file")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('onnxprep', xml_path, output_onnx_path), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'xmlprep' command, see console output")
    
    mesg = "xmlprep successful."
    return mesg

def info(input_file: str):
    # Opens a Beckhoff machine learning XML or BML model file and provides information about the
    # stored model.
    if len(input_file) < 1:
        raise ValueError("No input file specified.")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('info', input_file, None), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'info' command, see console output")

    info_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return info_mi[0][0].copy()


def store(input_file: str, output_file: str):
    # Stores a Beckhoff machine learning XML or BML model file at a different location with possible
    # conversion vom XML to BML or vice versa.
    if len(input_file) < 1:
        raise ValueError("No input file specified.")
    if len(output_file) < 1:
        raise ValueError("No output file specified.")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('store', input_file, output_file), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'store' command, see console output")

    store_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return store_mi[0][0].copy()


def convert(input_file: str, output_file: str, target_model_name: str):
    # Reads a Beckhoff machine learning XML or BML model file and attempts to convert the contained
    # model to a different type as specified by the target model name. If the conversion succeeds
    # the output is stored at the output file location as a Beckhoff machine learning XML or BML model file.
    if len(input_file) < 1:
        raise ValueError("No input file specified.")
    if len(output_file) < 1:
        raise ValueError("No output file specified.")
    if len(target_model_name) < 1:
        raise ValueError("No target model name specified.")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('convert', input_file, output_file, '',
                                                     'output_model="' + target_model_name + '"'), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'convert' command, see console output")

    convert_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return convert_mi[0][0].copy(), convert_mi[1][0].copy()


def hwinfo():
    # Returns a multi-level Python dictionary containing information about the hardware capabilities as
    # seen from the perspective of the Beckhoff machine learning runtime implemention.
    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('hwinfo', None, None), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'hwinfo' command, see console output")

    # Turn the XML response into a proper multi-layered Python dictionary
    hwcap = response.find("HardwareCapabilities")
    hw_cpu = hwcap.find("CPU")
    hw_caches = hw_cpu.find("Caches")

    hwi = {}
    hwi["CPU"] = {'Type': hw_cpu.find("Type").attrib.copy(),
                  'Features': hw_cpu.find("Features").attrib.copy(),
                  'PerformanceCounter': hw_cpu.find("PerformanceCounter").attrib.copy()}
    hwi["CPU"]["Type"]["vendor"] = hwi["CPU"]["Type"]["vendor"].strip()
    hwi["CPU"]["Type"]["model"] = hwi["CPU"]["Type"]["model"].strip()
    hwi["CPU"]["Features"]["simd128"] = hwi["CPU"]["Features"]["simd128"].split(" ")
    hwi["CPU"]["Features"]["simd256"] = hwi["CPU"]["Features"]["simd256"].split(" ")
    hwi["CPU"]["Features"]["simd512"] = hwi["CPU"]["Features"]["simd512"].split(" ")
    hwi["CPU"]["Features"]["misc"] = hwi["CPU"]["Features"]["misc"].split(" ")
    hwi["CPU"]["Features"]["os_support"] = hwi["CPU"]["Features"]["os_support"].split(" ")
    hwi["CPU"]["Features"]["avail_sse3"] = hwi["CPU"]["Features"]["avail_sse3"].lower() in ["true", "1"]
    hwi["CPU"]["Features"]["avail_avx"] = hwi["CPU"]["Features"]["avail_avx"].lower() in ["true", "1"]
    hwi["CPU"]["Features"]["avail_fma3"] = hwi["CPU"]["Features"]["avail_fma3"].lower() in ["true", "1"]
    hwi["CPU"]["Features"]["avail_avx512f"] = hwi["CPU"]["Features"]["avail_avx512f"].lower() in ["true", "1"]
    hwi["CPU"]["PerformanceCounter"]["frequency"] = int(hwi["CPU"]["PerformanceCounter"]["frequency"])
    hwi["CPU"]["PerformanceCounter"]["resolution_ns"] = int(hwi["CPU"]["PerformanceCounter"]["resolution_ns"])

    hwi["CPU"]["Caches"] = []
    for cache in hw_caches.iter("Cache"):
        hwi["CPU"]["Caches"].append(cache.attrib.copy())
    for cache in hwi["CPU"]["Caches"]:
        cache["coherency_line_size"] = int(cache["coherency_line_size"])
        cache["complex_indexing"] = cache["complex_indexing"].lower() in ["true", "1"]
        cache["inclusive"] = cache["inclusive"].lower() in ["true", "1"]
        cache["fully_associative"] = cache["fully_associative"].lower() in ["true", "1"]
        cache["self_initializing"] = cache["self_initializing"].lower() in ["true", "1"]
        cache["level"] = int(cache["level"])
        cache["physical_line_partitions"] = int(cache["physical_line_partitions"])
        cache["sets"] = int(cache["sets"])
        cache["shared_write_back_invalidating"] = cache["shared_write_back_invalidating"].lower() in ["true", "1"]
        cache["total_size"] = int(cache["total_size"])
        cache["ways_of_associativity"] = int(cache["ways_of_associativity"])

    return hwi


def modify_ca(input_file: str, output_file: str, new_custom_attributes):
    # Allows to replace the custom attributes of an existing Beckhoff machine learning XML or BML model file
    # and stores the modified data in the output file.
    if len(input_file) < 1:
        raise ValueError("No input file specified.")
    if len(output_file) < 1:
        raise ValueError("No output file specified.")

    def _write_atts_rec(parent_elem, parent_dict):
        for a, v in parent_dict.items():
            if isinstance(v, dict):
                new_elem = _ET.SubElement(parent_elem, a)
                _write_atts_rec(new_elem, v)            
            elif isinstance(v, list):
                s = ','.join([str(it) for it in v])
                if any(isinstance(it, str) or isinstance(it,bool) for it in v):
                    raise ValueError("Element in list '" + str(a) + "' cannot be used for custom attribute.")
                elif all(isinstance(it, int) for it in v):
                    parent_elem.attrib["arrint64_" + a] = s
                elif any(isinstance(it,float) for it in v):
                    parent_elem.attrib["arrfp64_" + a] = s
                else:
                    raise ValueError("Element in list '" + str(a) + "' cannot be used for custom attribute.")
            elif isinstance(v, bool):
                parent_elem.attrib["bool_" + a] = str(v)
            elif isinstance(v, int):
                parent_elem.attrib["int_" + a] = str(v)
            elif isinstance(v, str):
                parent_elem.attrib["str_" + a] = v
            elif isinstance(v, float):
                parent_elem.attrib["fp64_" + a] = str(v)
            else:
                raise ValueError("Type of key '" + str(a) + "' cannot be used for custom attribute.")

    mod_xml = ""
    add_xml = ""
    if new_custom_attributes is not None:
        if not isinstance(new_custom_attributes, dict):
            raise TypeError("New Custom Attributes structure is not a Python dictionary structure.")
        ca = _ET.Element("NewCustomAttributes")
        _write_atts_rec(ca, new_custom_attributes)
        mod_xml += str(_ET.tostring(ca))
        add_xml += ' bool_replace_custom_attributes="true"'

    mod_xml = "<Modifications " + add_xml + ">" + mod_xml + "</Modifications>"

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('modify', input_file, output_file, mod_xml), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'modify' command, see console output")

    modify_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return modify_mi[0][0].copy(), modify_mi[1][0].copy()

def iot_scaled_offset(offsets : list, scalings : list):
    if (len(offsets) != len(scalings)):
        raise ValueError("Length of offsets and scalings lists is not equal.")

    return 'str_type="SCALED_OFFSET" arrfp64_offsets="' + ','.join([str(x) for x in offsets]) + '" arrfp64_scalings="' + ','.join([str(x) for x in scalings]) + '"'

def modify_iot(input_file: str, output_file: str, input_trafo : str = None, output_trafo : str = None):
    # Allows to replace the I/O modifications of an existing Beckhoff machine learning XML or BML model file
    # and stores the modified data in the output file.
    if len(input_file) < 1:
        raise ValueError("No input file specified.")
    if len(output_file) < 1:
        raise ValueError("No output file specified.")

    mod_xml = "<NewIOTransformation><IOModification>"
    if input_trafo is not None:
        mod_xml += "<InputTransformation " + input_trafo + "/>"
    if output_trafo is not None:
        mod_xml += "<OutputTransformation " + output_trafo + "/>"
    mod_xml += "</IOModification></NewIOTransformation>"
    add_xml = ' bool_replace_io_transformation="true"'

    mod_xml = "<Modifications " + add_xml + ">" + mod_xml + "</Modifications>"

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('modify', input_file, output_file, mod_xml), 'utf-8')
    print(_xml_cmd)
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'modify' command, see console output")

    modify_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return modify_mi[0][0].copy(), modify_mi[1][0].copy()

def modify_md(input_file: str, output_file: str,
              new_version : str = None,       # Customer-managed version number string
              new_name : str = None,          # Name / Title of the model
              new_desc : str = None,          # Description of the model
              new_author : str = None,        # Author of the model
              new_tags : str = None):         # Comma-separated list of tags
    # Allows to replace the model description of an existing Beckhoff machine learning XML or BML model file
    # and stores the modified data in the output file.
    # Only supplied information other than 'None' will be replaced in the input file.
    # Use string '{{clear}}' to remove the current value found in the input file.

    if len(input_file) < 1:
        raise ValueError("No input file specified.")
    if len(output_file) < 1:
        raise ValueError("No output file specified.")

    ca = _ET.Element("NewModelDescription")
    if new_version is not None:
        ca.attrib['str_modelVersion'] = new_version
    if new_name is not None:
        ca.attrib['str_modelName'] = new_name
    if new_desc is not None:
        ca.attrib['str_modelDesc'] = new_desc
    if new_author is not None:
        ca.attrib['str_modelAuthor'] = new_author
    if new_tags is not None:
        ca.attrib['str_modelTags'] = new_tags

    mod_xml = "" + str(_ET.tostring(ca))
    add_xml = ' bool_replace_model_description="true"'

    mod_xml = "<Modifications " + add_xml + ">" + mod_xml + "</Modifications>"

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('modify', input_file, output_file, mod_xml), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'modify' command, see console output")

    modify_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return modify_mi[0][0].copy(), modify_mi[1][0].copy()

def predict(input_file: str, prediction: list):
    if len(input_file) < 1:
        raise ValueError("No input file specified.")
    if len(prediction) < 1:
        raise ValueError("No prediction data specified.")

    pred_str = '<Prediction>'
    for pred in prediction:
        data_str = '<Data1d '
        if 'input_type' in pred:
            data_str += "input_type='" + pred['input_type'] + "' "
        if 'output_type' in pred:
            data_str += "output_type='" + pred['output_type'] + "' "
        data_str += "input='" + ','.join([str(i) for i in pred['input']]) + "' "
        data_str += "/>"
        pred_str += data_str
    pred_str += '</Prediction>'

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('predict', input_file, None, pred_str), 'utf-8')
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)
    if response is None:
        raise RuntimeError("Errors occured during 'predict' command, see console output")

    modify_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    pred_out = response.find('PredictionOutput')
    out_arr = []

    def split_and_convert_arr(type: str, csv_string: str):
        if type in ['fp32', 'fp64', 'fp']:
            return [float(i) for i in csv_string.split(',')]
        elif type in ['int8', 'int16', 'int32', 'int64', 'int']:
            return [int(i) for i in csv_string.split(',')]
        else:
            raise ValueError("Invalid output data type.")

    for data1d in pred_out.iter('Data1d'):
        in_type = data1d.attrib['input_type']
        out_type = data1d.attrib['output_type']
        out_arr.append({ 'input_type' : in_type, 'output_type': out_type,
                         'input': split_and_convert_arr(in_type, data1d.attrib["input"]),
                         'output': split_and_convert_arr(out_type, data1d.attrib["output"]) })
    return out_arr

def input_engine(input_filename: str, full_engine_name: str, opt_reference_name_in_output: str = ''):
    if len(opt_reference_name_in_output) < 1:
        return {'filename': input_filename, 'eng': full_engine_name}
    else:
        return {'filename': input_filename, 'eng': full_engine_name, 'ref': opt_reference_name_in_output}

def input_reference(input_filename: str, reference_name: str, opt_reference_name_in_output: str = ''):
    if len(opt_reference_name_in_output) < 1:
        return {'filename': input_filename, 'iref': reference_name}
    else:
        return {'filename': input_filename, 'iref': reference_name, 'ref': opt_reference_name_in_output}

def merge(input_files: list, output_file: str):
    if len(input_files) < 2:
        raise ValueError("Need at least two input files.")
    if len(output_file) < 1:
        raise ValueError("No output file specified.")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('merge', input_files, output_file), 'utf-8')
    print(_xml_cmd)
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'merge' command, see console output")

    merge_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return merge_mi[0][0].copy(), merge_mi[1][0].copy()

def extract(input_file_spec: dict, output_file: str):
    if len(output_file) < 1:
        raise ValueError("No output file specified.")

    _xml_cmd = bytes(_MLlibUM_DLLwrapper._FormXMLcmd('extract', [input_file_spec], output_file), 'utf-8')
    print(_xml_cmd)
    (msg_list, response) = _MLlibUM_DLLwrapper._ExecXMLcmd(_xml_cmd)

    if response is None:
        raise RuntimeError("Errors occured during 'merge' command, see console output")

    extract_mi = _MLlibUM_DLLwrapper._ShowIOModelInfo(response)
    return extract_mi[0][0].copy(), extract_mi[1][0].copy()